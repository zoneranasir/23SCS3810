-- CS3810: Principles of Database Systems
-- Instructor: Thyago Mota
-- Student(s): Zonera Nasir
-- Description: SQL for the In-N-Out Store

DROP DATABASE innout;

CREATE DATABASE innout;

\c innout

-- TODO: table create statements
-- Customers table create statement:
CREATE TABLE Customers (
customer_id SERIAL PRIMARY KEY,
customer_name VARCHAR(50) NOT NULL,
gender CHAR(1) NOT NULL DEFAULT '?'
);

-- Items table create statement:
CREATE TABLE Items (
item_code VARCHAR(10) PRIMARY KEY,
description VARCHAR(50) NOT NULL,
price DECIMAL(10,2) NOT NULL,
category_code VARCHAR(3) REFERENCES Categories(category_code)
);

-- Categories table create statement:
CREATE TABLE Categories (
category_code VARCHAR(3) PRIMARY KEY,
description VARCHAR(50) NOT NULL
);

-- Sales table create statement:
CREATE TABLE Sales (
sale_id SERIAL PRIMARY KEY,
customer_id INTEGER REFERENCES Customers(customer_id) NOT NULL,
item_code VARCHAR(10) REFERENCES Items(item_code) NOT NULL,
sale_date TIMESTAMP NOT NULL,
sale_price DECIMAL(10,2) NOT NULL,
quantity INTEGER NOT NULL
);


-- TODO: table insert statements
INSERT INTO Categories (category_code, description) VALUES 
    ('BVR', 'Beverages'),
    ('DRY', 'Dairy'),
    ('PRD', 'Produce'),
    ('FRZ', 'Frozen'),
    ('BKY', 'Bakery'),
    ('MEA', 'Meat'),
    ('SPI', 'Spices');

INSERT INTO Customers (customer_name, gender) VALUES
    ('Ammar', 'M'),
    ('Zonera', 'F'),
    ('Hamster', 'M'),
    ('Hamza', '?'),
    ('Selena', 'F'),
    ('Noah', 'M');

INSERT INTO Items (item_code, description,price, category_code) VALUES
    (01,'pepsi',1.50,'BVR'),
    (02,'fanta',1.45,'BVR'),
    (03,'oatmilk',5.50,'DRY'),
    (04,'whole milk',3.50,'DRY'),
    (05,'apple',1.25,'PRD'),
    (06,'cilantro',0.25,'PRD'),
    (07,'pizza',4.50,'FRZ'),
    (08,'potato wedges',6.50,'FRZ'),
    (09,'cheesecake',7.59,'BKY'),
    (10,'crossiants',3.50,'BKY'),
    (11,'Whole chicken',6.59,'MEA'),
    (12,'steak',10.50,'MEA');
    (13,'brocolli',4.50, NULL),


INSERT INTO Sales (customer_id, item_code, sale_date, sale_price,quantity) VALUES
    (1,02, TIMESTAMP '2023-01-06 01:00', 1.45, 3 ),
    (3,03, TIMESTAMP '2023-02-12 04:00', 5.50, 1 ),
    (4,07, TIMESTAMP '2023-03-15 04:30', 4.50, 2 ),
    (2,12, TIMESTAMP '2023-02-28 01:30', 10.50, 1 ),
    (5,06, TIMESTAMP '2023-01-07 03:00', 0.25, 3 ),
    (1,08, TIMESTAMP '2023-03-14 05:25', 6.50, 1 ),
    (3,05, TIMESTAMP '2023-03-22 06:55', 1.25, 10 ),
    (5,10, TIMESTAMP '2023-02-11 08:59', 3.50, 15 ),
    (2,04, TIMESTAMP '2023-01-17 10:30', 3.50, 1 );

-- TODO: SQL queries

-- a) all customer names in alphabetical order
SELECT customer_name FROM Customers ORDER BY customer_name ASC;

-- b) number of items (labeled as total_items) in the database 
SELECT COUNT(*) AS total_items FROM Items;

-- c) number of customers (labeled as number_customers) by gender
SELECT gender, COUNT(*) AS number_customers FROM Customers GROUP BY gender;

-- d) a list of all item codes (labeled as code) and descriptions (labeled as description) followed by their category descriptions (labeled as category) in numerical order of their codes (items that do not have a category should not be displayed)
SELECT Items.item_code AS code, Items.description AS description, Categories.description AS category
FROM Items
LEFT JOIN Categories ON Items.category_code = Categories.category_code
WHERE Items.category_code IS NOT NULL
ORDER BY Items.item_code::int;

-- e) a list of all item codes (labeled as code) and descriptions (labeled as description) in numerical order of their codes for the items that do not have a category
SELECT item_code AS code, description
FROM Items
WHERE category_code IS NULL
ORDER BY item_code::int;

-- f) a list of the category descriptions (labeled as category) that do not have an item in alphabetical order
SELECT Categories.description AS category
FROM Categories
LEFT JOIN Items ON Categories.category_code = Items.category_code
WHERE Items.category_code IS NULL
ORDER BY Categories.description ASC;

-- g) set a variable named "ID" and assign a valid customer id to it; then show the content of the variable using a select statement
\set id '2'
SELECT * FROM customers where customers.customer_id = :'id';

-- h) a list describing all items purchased by the customer identified by the variable "ID" (you must used the variable), showing, the date of the purchase (labeled as date), the time of the purchase (labeled as time and in hh:mm:ss format), the item's description (labeled as item), the quantity purchased (labeled as qtt), the item price (labeled as price), and the total amount paid (labeled as total_paid).
SELECT
sale_date::date AS date,
sale_date::time(0) AS time,
Items.description AS item,
quantity AS qtt,
sale_price AS price,
quantity * sale_price AS total_paid
FROM Sales
JOIN Customers ON Sales.customer_id = Customers.customer_id
JOIN Items ON Sales.item_code = Items.item_code
WHERE Customers.customer_id = :'id';

-- i) the total amount of sales per day showing the date and the total amount paid in chronological order
SELECT DATE_TRUNC('day', sale_date) AS date, SUM(sale_price * quantity) AS total_amount
FROM Sales
GROUP BY DATE_TRUNC('day', sale_date)
ORDER BY date ASC;

-- j) the description of the top item (labeled as item) in sales with the total sales amount (labeled as total_paid)
SELECT Items.description AS item, SUM(Sales.sale_price * Sales.quantity) AS total_paid
FROM Sales
INNER JOIN Items ON Sales.item_code = Items.item_code
GROUP BY Items.description
ORDER BY total_paid DESC
LIMIT 1;

-- k) the descriptions of the top 3 items (labeled as item) in number of times they were purchased, showing that quantity as well (labeled as total)
SELECT Items.description AS item, SUM(Sales.quantity) AS total
FROM Sales
INNER JOIN Items ON Sales.item_code = Items.item_code
GROUP BY Items.description
ORDER BY total DESC
LIMIT 3;

-- l) the name of the customers who never made a purchase 
SELECT customer_name
FROM Customers
LEFT JOIN Sales ON Customers.customer_id = Sales.customer_id
WHERE Sales.sale_id IS NULL;